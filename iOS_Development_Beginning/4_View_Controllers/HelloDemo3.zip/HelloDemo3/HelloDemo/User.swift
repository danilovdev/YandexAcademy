//
//  User.swift
//  HelloDemo
//
//  Created by Alexey Danilov on 7/20/19.
//  Copyright © 2019 DanilovDev. All rights reserved.
//

class User {
    
    var username: String
    
    init(username: String) {
        self.username = username
    }
}
